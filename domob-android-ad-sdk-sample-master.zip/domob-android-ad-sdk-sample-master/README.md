Welcome To Use Domob Android Ad SDK!
===========================
## 注意事项：

当开发者在运行 **Domob Sampe** 时，如果出现 **ClassNotFoundException**，则可能是由于`libs/domob_android_sdk.jar`并不存在于`build path`中。

这时候，请在项目设置中选择 `Java Build Path` => `Order and Export`，并勾选其中的 `Android Private Libraries`。